


<?php
    // My modifications to mailer script from:
    // http://blog.teamtreehouse.com/create-ajax-contact-form
    // Added input sanitizing to prevent injection

    // Only process POST reqeusts.
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get the form fields and remove whitespace.
        $name = strip_tags(trim($_POST["name"]));
				$name = str_replace(array("\r","\n"),array(" "," "),$name);
        $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
        $age = trim($_POST["age"]);
        $phone = trim($_POST["phone"]);
        $study = trim($_POST["study"]);
        $film = trim($_POST["film"]);
        $track = trim($_POST["track"]);
        $quote = trim($_POST["quote"]);
        $track = trim($_POST["track"]);
        $marketing = trim($_POST["marketing"]);

        // Check that data was sent to the mailer.
        if ( empty($name) OR  empty($phone)  OR empty($phone)  OR empty($study)  OR empty($age) OR empty($film) OR empty($track) OR empty($quote) OR empty($track) OR !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            // Set a 400 (bad request) response code and exit.
            http_response_code(400);
            echo "Oops! There was a problem with your submission. Please complete the form and try again.";
            exit;
        }

        // Set the recipient email address.
        // FIXME: Update this to your desired email address.
        $recipient = "aly@societamedia.com";

        // Set the email subject.
        $subject = "internship | New contact from $name";

        // Build the email content.
        $email_content = "Name: \n$name\n";
        $email_content = "Age: \n$age\n";
        $email_content .= "Email: \n$email\n\n";
        $email_content = "Phone: \n$phone\n";
        $email_content = "Study: \n$study\n";
        $email_content .= "Film: \n$film \n\n";
        $email_content .= "Quote: \n$quote\n\n";
        $email_content .= "Track: \n$track\n\n";
        $email_content .= "Marketing:\n$marketing\n";

        // Build the email headers.
        $email_headers = "internship | From: $name <$email>";

        // Send the email.
        if (mail($recipient, $subject, $email_content, $email_headers)) {
            // Set a 200 (okay) response code.
            http_response_code(200);
            echo "Thank You! Your message has been sent.";
        } else {
            // Set a 500 (internal server error) response code.
            http_response_code(500);
            echo "Oops! Something went wrong and we couldn't send your message.";
        }

    } else {
        // Not a POST request, set a 403 (forbidden) response code.
        http_response_code(403);
        echo "There was a problem with your submission, please try again.";
    }

?>
