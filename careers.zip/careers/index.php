<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>

  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta property="og:title" content='Careers' />
  <meta property="og:url" content="http://careers.societamedia.com" />
  <meta property="og:image" content="../img/og-image.jpg" />
  <link rel="shortcut icon" href="../img/fav.png" type="image/x-icon">
  <link rel="icon" href="img/fav.png" type="image/x-icon">
  <meta name="viewport" content="width=device-width, initial-scale=1,  maximum-scale=1">
  <link href="https://fonts.googleapis.com/css?family=Acme" rel="stylesheet">
  <meta name="theme-color" content="#224294">
  <title>Societa | Careers</title>
  <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Open+Sans:600'>

      <link rel="stylesheet" href="css/style.css">
<script src="script.js">

</script>

</head>

<body>

  <div class="sign-wrap">



	<h1>Apply now for Societa internship</h1>
<h3 style="margin-top:5px; font-size:0.9em; margin-left:5px; line-height:1.2em">Apply for the 3 months unpaid internship for medical students with good to excellent proficiency in English and passionate about marketing and business development.</h3>

<hr>
<div id="form-messages"></div>
<form id="ajax-contact" method="post" action="send_form_email.php">



			<div class="group"> <input type="text" id="name" name="name" required> <span class="highlight"></span> <span class="bar"></span> <label>Name: *</label> </div>
			<div class="group"> <input type="email" id="email" name="email" required> <span class="highlight"></span> <span class="bar"></span> <label>Email: *</label> </div>
			<div class="group"> <input type="text" id="phone" name="phone" required> <span class="highlight"></span> <span class="bar"></span> <label>Phone: *</label> </div>
	<div class="group"> <input type="text" id="age" name="age" required> <span class="highlight"></span> <span class="bar"></span> <label>Age: *</label> </div>
    	<div class="group"> <input type="text" id="study" name="study" required> <span class="highlight"></span> <span class="bar"></span> <label>Study place: *</label> </div>
        	<div class="group"> <input type="text" id="film" name="film" required> <span class="highlight"></span> <span class="bar"></span> <label>Your favourite film is ? *</label> </div>
            	<div class="group"> <input type="text" id="track" name="track" required> <span class="highlight"></span> <span class="bar"></span> <label>Your favourite track is ? *</label> </div>
            	<div class="group"> <input type="text" id="quote" name="quote" required> <span class="highlight"></span> <span class="bar"></span> <label>Your favourite quote is ? *</label> </div>
            	<div class="group"> <input type="text" id="track" name="track" required> <span class="highlight"></span> <span class="bar"></span> <label>Your favourite track is ? *</label> </div>
            	<div class="group"> <textarea style="padding: 10px 10px 25px 5px;" name="marketing" id="marketing" required></textarea> <span class="highlight"></span> <span class="bar"></span> <label>Mention any experience related to the business development or marketing: *</label> </div>
<input type="submit" name="" value="Submit">




  </form>
  <hr>
    <footer class="footer">
      <a href="http://www.societamedia.com"><img style="float:right;" src="logo-blue.svg" class="nav-logo " alt="societa"></a>
  </footer>
	</div>



</body>
</html>
